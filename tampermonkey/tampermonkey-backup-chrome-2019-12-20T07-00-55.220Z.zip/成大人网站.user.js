// ==UserScript==
// @name         成大人网站
// @namespace    http://tampermonkey.net/
// @version      0.3
// @description  一些可以使用的成大人网站，并且去掉部分广告。网站请自行复制（更新以下网站：开胯啪、废柴、蝌蚪窝、91）。欢迎留言补充！
// @author       shillber
// @match        *://kaikuapa.xyz/*
// @match        *://fcww16.com/*
// @match        *://xiaobi006.com/*
// @match        *://627.workarea7.live/*
// @grant        none
// ==/UserScript==

(function() {
function clearAds(elm, array_url) {
    var isUrl = false;
    for (var x = 0; x < array_url.length; x++) {
        if (location.href.match(array_url[x])) {
            isUrl = true;
        };
    };
    if (isUrl) {
        var head = document.getElementsByTagName('head')[0];
        var myStyle = document.createElement('style');
        myStyle.type = "text/css";
        myStyle.innerHTML = elm + "{display:none !important;visibility:hidden !important;width:0 !important;height:0 !important;}";
        head.appendChild(myStyle);
    };
};
clearAds("", ["kaikuapa.xyz"]);
clearAds(".top-links,.content:nth-of-type(2),.nav,.sponsor", ["fcww16.com.com"]);
clearAds(".cz, .layui-layer-content, #bottompf,#class2,#layui-layer-shade1,.s1,.pc_ad,.top-links,.sponsor,[src*='long88.app'],[src*='img.alicdn.com']", ["xiaobi006.com"]);
clearAds(".removeSpan,#topbar", ["627.workarea7.live"]);
})();